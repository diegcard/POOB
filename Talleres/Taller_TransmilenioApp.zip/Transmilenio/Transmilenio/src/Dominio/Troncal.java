package Dominio;

/**
 * Transporte del sistema
 */
public class Troncal {
}
