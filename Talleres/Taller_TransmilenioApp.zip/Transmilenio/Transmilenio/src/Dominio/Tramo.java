package Dominio;

/**
 * Transporte del sistema
 */
public class Tramo {
    public int distancia;
}