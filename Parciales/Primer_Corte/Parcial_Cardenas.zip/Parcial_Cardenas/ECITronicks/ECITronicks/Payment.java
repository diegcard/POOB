import java.time.LocalDate;

public class Payment {
	private char method;
	private int amount;
	private LocalDate createAt;

}
