import java.util.ArrayList;
import java.util.HashMap;

public class Store {

    private String name;
    private String address;
    private String atentionSchedule;
    private ArrayList<Employee> employees;
    private ArrayList<Supplier> suppliers;
    private ArrayList<Bill> bills;
    private ArrayList<Product> products;
    private Location location;

    /**
     * Retorna el mejor empleado comparando las ventas y que una venta tenga almenos un pago y despues se compara cual fue el empleado que mayor vendio y se retorna
     * @return Employee
     */
    public Employee getBestEmployee(){
        ArrayList<Integer> totalPorEmpleado = new ArrayList<Integer>();
        for(int i = 0; i<employees.size(); i++){
            totalPorEmpleado.add(0);
        }
        int amountMax = 0;
        int index = 0;
        for (Bill b: bills){
            int tot = 0;
            Employee em = b.getEmployee();
            for(Employee e: employees){
                if(em == e){
                    ArrayList<Payment> p = b.getPayments();
                    if(p.size() > 0){
                        tot+=b.getTotal();
                    }
                }
            }
            for(int i = 0; i < employees.size(); i++){
                if(employees.get(i).equals(em)){
                    Integer total = totalPorEmpleado.get(i) + tot;
                    totalPorEmpleado.set(i, total);
                }
            }
        }
        for(int i =0; i< totalPorEmpleado.size(); i++){
            if(totalPorEmpleado.get(i) > amountMax){
                amountMax = totalPorEmpleado.get(i);
                index = i;
            }
        }

        return employees.get(index);

    }
    
}
