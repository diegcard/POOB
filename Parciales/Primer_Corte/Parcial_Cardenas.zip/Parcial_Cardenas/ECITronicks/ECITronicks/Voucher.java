import java.time.LocalDate;

public class Voucher {

	private LocalDate date;
	private int value;
	private boolean spend;

}
