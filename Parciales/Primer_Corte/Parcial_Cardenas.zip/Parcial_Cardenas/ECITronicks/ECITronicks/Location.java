import java.util.ArrayList;

public class Location {

	private String city;
	private String neighborhood;
	private ArrayList<Store> stores;

}
