import java.util.*;

/**
 * Reaalizado por Diego Cardenas
 */
public class ECITronicks {
    HashMap<String, Store> stores;

    /**
     * Dado el nombre de una tienda lo que toca hacer es retornar el mejor empleado de esa tienda dada
     *
     * @param storeName: Nombre de la tienda
     * @return Employee
     */
    public Employee bestEmployeeByStore(String storeName){
        Store storeActual = stores.get(storeName);
        Employee bestEmployee;
        if (storeActual != null){
            bestEmployee = storeActual.getBestEmployee();
            return bestEmployee;
        }
        return null;
    }
}
