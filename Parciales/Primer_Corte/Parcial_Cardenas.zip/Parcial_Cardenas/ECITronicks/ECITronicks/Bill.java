import java.time.LocalDate;
import java.util.ArrayList;

public class Bill {

	private LocalDate date;
	private int total;
	private ArrayList<Payment> payments;
	private ArrayList<BillLine> lines;
	private Store store;
	private Client client;
	private Employee employee;
	private Voucher voucher;

	/**
	 * Retorna el Empleado
	 * @return Employee
	 */

	public Employee getEmployee(){
		return employee;
	}

	/**
	 * Retorna la lista de Pagos
	 * @return ArrayList<Payment>
	 */
	public ArrayList<Payment> getPayments(){
		return payments;
	}

	/**
	 * Retorna el total de la venta
	 * @return int
	 */
	public int getTotal(){
		return total;
	}

}
