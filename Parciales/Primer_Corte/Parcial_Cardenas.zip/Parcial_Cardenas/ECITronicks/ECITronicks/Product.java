public class Product {

	private String name;
	private String brand;
	private String description;
	private int unitPrice;
	private int discount;

}
