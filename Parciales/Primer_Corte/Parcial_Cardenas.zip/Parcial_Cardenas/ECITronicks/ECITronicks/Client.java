import java.util.ArrayList;

public class Client {

	private Integer id;
	private String name;
	private String address;
	private String cellphone;
	private String email;
	private ArrayList<Voucher> vouchers;

}
