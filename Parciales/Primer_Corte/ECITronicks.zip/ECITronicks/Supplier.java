import java.util.ArrayList;

public class Supplier {

	private String name;
	private int contactNumber;
	private ArrayList<Product> products;

}
