public class BillLine {
    
	private int amount;
	private int price;
	private Product product;
	
}
