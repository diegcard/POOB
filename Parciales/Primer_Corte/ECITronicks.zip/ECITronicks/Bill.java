import java.time.LocalDate;
import java.util.ArrayList;

public class Bill {

	private LocalDate date;
	private int total;
	private ArrayList<Payment> payments;
	private ArrayList<BillLine> lines;
	private Store store;
	private Client client;
	private Employee employee;
	private Voucher voucher;

}
