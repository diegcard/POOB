import java.util.ArrayList;

public class Store {

	private String name;
	private String address;
	private String atentionSchedule;
	private ArrayList<Employee> employees;
	private ArrayList<Supplier> suppliers;
	private ArrayList<Bill> bills;
	private ArrayList<Product> products;
	private Location location;

}
