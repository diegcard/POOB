/**
 * @author ECI, 2024
 *
 */
public class DataMatrix{

    private Data [][] data;
    
    /**
     * Creates a matrix with the defined size and value
     */
    public DataMatrix(String [][] data) {
    }
    
    public DataMatrix shape(){
        return null;
    }
    
    
    public String toString(int row, int column){
        return "";
    }
    
    public DataMatrix reshape(int row, int column){
        return null;
    }
    
    public DataMatrix add(DataMatrix t){
        return null;
    }


    
    public boolean equals(DataMatrix other) {
            return false;
    }
    
    @Override
    public boolean equals(Object other) {
            return equals((DataMatrix)other);
    }
    
    @Override
    public String toString () {
          return null;
    }   
 
}
