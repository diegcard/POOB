package Square.src.test;

import Square.src.domain.Square;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;

import static org.junit.jupiter.api.Assertions.*;


public class SquareTest {
    private Square square;
    private JButton[][] buttons;
    private Square[][] squares;

    @BeforeEach
    public void setUp() {
        buttons = new JButton[5][5];
        squares = new Square[5][5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                buttons[i][j] = new JButton();
                squares[i][j] = new Square(Color.WHITE, Color.WHITE, squares, buttons);
            }
        }
        square = new Square(Color.RED, Color.WHITE, squares, buttons);
    }

    @Test
    public void squareShouldNotMoveWhenSetCanMoveIsFalse() {
        square.setCanMove(false);
        assertFalse(square.isMove());
    }

    @Test
    public void squareShouldMoveWhenSetCanMoveIsTrue() {
        square.setCanMove(true);
        assertTrue(square.isMove());
    }

    @Test
    public void squareShouldMoveRightWhenMoveRightIsCalled() {
        square.moveRight(2, 2);
        assertEquals(Color.RED, squares[2][3].getColor());
    }

    @Test
    public void squareShouldMoveDownWhenMoveDownIsCalled() {
        square.moveDown(2, 2);
        assertEquals(Color.RED, squares[3][2].getColor());
    }

    @Test
    public void squareShouldMoveLeftWhenMoveLeftIsCalled() {
        square.moveLeft(2, 2);
        assertEquals(Color.RED, squares[2][1].getColor());
    }

    @Test
    public void squareShouldMoveUpWhenMoveUpIsCalled() {
        square.moveUp(2, 2);
        assertEquals(Color.RED, squares[1][2].getColor());
    }

    @Test
    public void colorShouldRemainSameWhenChangeColorIsCalledWithNull() {
        Color initialColor = square.getColor();
        square.changeColor(null);
        assertEquals(initialColor, square.getColor());
    }

    @Test
    public void borderColorShouldRemainSameWhenChangeColorIsCalledWithNull() {
        Color initialBorderColor = square.getBorderColor();
        square.changeColor(null);
        assertEquals(initialBorderColor, square.getBorderColor());
    }


}