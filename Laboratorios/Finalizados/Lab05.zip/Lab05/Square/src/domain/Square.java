package Square.src.domain;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.HashMap;

/**
 * The square class is a class that represents a square.
 * It has the following attributes:
 *
 * @author Diego Cardenas
 * @author Sebastian Cardona
 * @version 1.0
 */
public class Square {
    private Color color;
    private Color borderColor;
    private Square[][] squares;
    private JButton[][] buttons;
    private boolean canMove = true;
    private HashMap<String, Color> buttonsColors = new HashMap<>();
    private boolean isNotWiner = false;

    /**
     * Constructor de la clase Square
     *
     * @param color       Color de la ficha
     * @param borderColor Color del borde de la ficha
     * @param squares     Cuadrados
     * @param buttons     Botones
     */
    public Square(Color color, Color borderColor, Square[][] squares, JButton[][] buttons) {
        this.color = color;
        this.borderColor = borderColor;
        this.squares = squares;
        this.buttons = buttons;
    }

    /**
     * Cambia el color de la ficha
     *
     * @param borderColor Color del borde de la ficha
     */
    public void changeColor(Color borderColor) {
        if (!this.color.equals(Color.BLACK)) {
            Color newColor = JColorChooser.showDialog(null, "Choose a color", this.color);
            if (newColor != null) {
                this.color = newColor;
                this.borderColor = borderColor;
            }
        }
    }

    /**
     * Obtiene los cuadrados
     *
     * @return Cuadrados
     */
    public Square[][] getSquares() {
        return squares;
    }

    /**
     * Establece los cuadrados
     *
     * @return Cuadrados
     */
    public JButton[][] getButtons() {
        return buttons;
    }

    /**
     * Obtiene el color de la ficha
     *
     * @return Color de la ficha
     */
    public Color getColor() {
        return color;
    }

    /**
     * Obtiene el color del borde de la ficha
     *
     * @return Color del borde de la ficha
     */
    public Color getBorderColor() {
        return borderColor;
    }

    /**
     * Establece el color de la ficha
     *
     * @param color Color de la ficha
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Establece el color del borde de la ficha
     *
     * @param borderColor Color del borde de la ficha
     */
    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
    }

    /**
     * Verifica si la ficha se puede mover
     *
     * @return true si la ficha se puede mover, false en caso contrario
     */
    public boolean isMove() {
        return canMove;
    }

    /**
     * Establece si la ficha se puede mover
     *
     * @param canMove true si la ficha se puede mover, false en caso contrario
     */
    public void setCanMove(boolean canMove) {
        this.canMove = canMove;
    }

    /**
     * Verifica si el jugador ha ganado
     *
     * @return true si el jugador ha ganado, false en caso contrario
     */
    public boolean isNotWiner() {
        return isNotWiner;
    }


    /**
     * Verifica si hay huecos en el tablero
     */
    public void verificarHuecos() {
        for (String position : buttonsColors.keySet()) {
            String[] coordinates = position.split(",");
            int row = Integer.parseInt(coordinates[0]);
            int column = Integer.parseInt(coordinates[1]);

            Color color = buttonsColors.get(position);

            if (buttons[row][column].getBackground().equals(Color.WHITE)) {
                buttons[row][column].setBackground(color);
                squares[row][column].setCanMove(false);
            }
        }
    }

    /**
     * Verifica si un botón es un hueco tapado
     *
     * @param row    Fila del botón
     * @param column Columna del botón
     * @return true si el botón es un hueco tapado, false en caso contrario
     */
    public boolean isTappedHole(int row, int column) {
        // Verifica si el fondo del botón es distinto de blanco
        boolean isBackgroundNotWhite = !buttons[row][column].getBackground().equals(Color.WHITE);

        // Verifica si la ficha no se puede mover
        boolean cannotMove = !squares[row][column].isMove();

        // Un botón es un hueco tapado si su fondo es distinto de blanco y la ficha no se puede mover
        return isBackgroundNotWhite && cannotMove;
    }

    /**
     * Verifica si un botón es un hueco
     *
     * @param row    Fila del botón
     * @param column Columna del botón
     * @return true si el botón es un hueco, false en caso contrario
     */
    public boolean isHole(int row, int column) {
        // Verifica si el fondo del botón es blanco
        boolean isBackgroundWhite = buttons[row][column].getBackground().equals(Color.WHITE);

        // Verifica si el borde del botón está pintado
        boolean isBorderPainted = false;
        if (buttons[row][column].getBorder() instanceof LineBorder) {
            LineBorder border = (LineBorder) buttons[row][column].getBorder();
            isBorderPainted = !border.getLineColor().equals(Color.WHITE);
        }
        // Un botón es un hueco si su fondo es blanco y su borde está pintado
        return isBackgroundWhite && isBorderPainted;
    }

    /**
     * Verifica si un botón tiene un borde pintado
     *
     * @param button Botón a verificar
     * @return true si el botón tiene un borde pintado, false en caso contrario
     */
    public boolean hasPaintedBorder(JButton button) {
        if (button.getBorder() instanceof LineBorder) {
            LineBorder border = (LineBorder) button.getBorder();
            // Comprueba si el color del borde no es blanco
            return !border.getLineColor().equals(Color.WHITE);
        }
        return false;
    }

    /**
     * Verifica si un cuadrado tiene un borde pintado
     *
     * @param square Cuadrado a verificar
     * @return true si el cuadrado tiene un borde pintado, false en caso contrario
     */
    public boolean hasOnlyBorderColored(Square square) {
        Color borderColor = square.getBorderColor();
        return borderColor != null && !borderColor.equals(Color.WHITE);
    }

    /**
     * Verifica si un botón tiene un borde de un color distinto al color del jugador
     *
     * @param button Botón a verificar
     * @return true si el borde del botón es de un color distinto al color del jugador, false en caso contrario
     */
    public boolean hasDifferentBorderColor(JButton button) {
        if (button.getBorder() instanceof LineBorder) {
            LineBorder border = (LineBorder) button.getBorder();
            if (border.getLineColor().equals(Color.WHITE)) {
                return false;
            }
            return !border.getLineColor().equals(this.color);
        }
        return false;
    }

    /**
     * Verifica si un hueco ha sido tapado
     *
     * @param button Botón a verificar
     * @return true si el hueco ha sido tapado, false en caso contrario
     */
    public boolean isHoleTapped(JButton button) {
        if (button.getBorder() instanceof LineBorder) {
            LineBorder border = (LineBorder) button.getBorder();
            // Comprueba si el color del botón es distinto de blanco (ha sido tapado)
            // y si el botón tiene un borde pintado (era un hueco)
            return !button.getBackground().equals(Color.WHITE) && !border.getLineColor().equals(Color.WHITE);
        }
        return false;
    }

    /**
     * Mueve la ficha hacia la derecha
     *
     * @param currentRow    Fila actual de la ficha
     * @param currentColumn Columna actual de la ficha
     */
    public void moveRight(int currentRow, int currentColumn) {
        moveToken(currentRow, currentColumn, MoveDirection.RIGHT);
    }

    /**
     * Mueve la ficha hacia abajo
     *
     * @param currentRow    Fila actual de la ficha
     * @param currentColumn Columna actual de la ficha
     */
    public void moveDown(int currentRow, int currentColumn) {
        moveToken(currentRow, currentColumn, MoveDirection.DOWN);
    }

    /**
     * Mueve la ficha hacia la izquierda
     *
     * @param currentRow    Fila actual de la ficha
     * @param currentColumn Columna actual de la ficha
     */
    public void moveLeft(int currentRow, int currentColumn) {
        moveToken(currentRow, currentColumn, MoveDirection.LEFT);
    }

    /**
     * Mueve la ficha hacia arriba
     *
     * @param currentRow    Fila actual de la ficha
     * @param currentColumn Columna actual de la ficha
     */
    public void moveUp(int currentRow, int currentColumn) {
        moveToken(currentRow, currentColumn, MoveDirection.UP);
    }

    /**
     * Mueve la ficha en la dirección especificada
     *
     * @param currentRow    Fila actual de la ficha
     * @param currentColumn Columna actual de la ficha
     * @param moveDirection Dirección en la que se moverá la ficha
     */
    private void moveToken(int currentRow, int currentColumn, MoveDirection moveDirection) {
        if (!this.isMove()) {
            return;
        }

        int newRow = currentRow;
        int newColumn = currentColumn;

        switch (moveDirection) {
            case RIGHT:
                newColumn = currentColumn + 1;
                break;
            case DOWN:
                newRow = currentRow + 1;
                break;
            case LEFT:
                newColumn = currentColumn - 1;
                break;
            case UP:
                newRow = currentRow - 1;
                break;
        }

        if (isValidMove(currentRow, currentColumn, newRow, newColumn)) {
            Square targetSquare = squares[newRow][newColumn];

            if (hasDifferentBorderColor(buttons[newRow][newColumn]) && !isHoleTapped(buttons[newRow][newColumn])) {
                JOptionPane.showMessageDialog(null, "Perdiste", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                isNotWiner = false;
                return;
            }

            if (isHole(newRow, newColumn)) {
                targetSquare.setColor(this.color);
                this.color = color.white;
                buttons[currentRow][currentColumn].setBackground(this.color);
                buttons[newRow][newColumn].setBackground(targetSquare.getColor());
                buttons[newRow][newColumn].setBorder(null);
                targetSquare.setCanMove(false);
                if (targetSquare.getColor().equals(this.color)) {
                    buttons[newRow][newColumn].setBackground(this.color);
                }
                String position = newRow + "," + newColumn;
                buttonsColors.put(position, targetSquare.getColor());
            } else if (isTappedHole(newRow, newColumn)) {
                targetSquare.setCanMove(true);
                targetSquare.setColor(this.color);
                this.color = color.white;
                buttons[currentRow][currentColumn].setBackground(this.color);
                buttons[newRow][newColumn].setBackground(targetSquare.getColor());
            } else {
                targetSquare.setColor(this.color);
                this.color = color.white;
                buttons[currentRow][currentColumn].setBackground(this.color);
                buttons[newRow][newColumn].setBackground(targetSquare.getColor());
            }
        }

        verificarHuecos();
    }

    /**
     * Verifica si un movimiento es válido
     *
     * @param currentRow    Fila actual de la ficha
     * @param currentColumn Columna actual de la ficha
     * @param newRow        Fila a la que se moverá la ficha
     * @param newColumn     Columna a la que se moverá la ficha
     * @return true si el movimiento es válido, false en caso contrario
     */
    private boolean isValidMove(int currentRow, int currentColumn, int newRow, int newColumn) {
        return !hasPaintedBorder(buttons[currentRow][currentColumn]) &&
                !buttons[currentRow][currentColumn].getBackground().equals(Color.WHITE) &&
                !isNotWiner &&
                isInBounds(newRow, newColumn) &&
                (squares[newRow][newColumn].getColor().equals(Color.WHITE) || hasOnlyBorderColored(squares[newRow][newColumn]));
    }

    /**
     * Verifica si una posición está dentro de los límites del tablero
     *
     * @param row    Fila
     * @param column Columna
     * @return true si la posición está dentro de los límites del tablero, false en caso contrario
     */
    private boolean isInBounds(int row, int column) {
        return row >= 0 && row < squares.length && column >= 0 && column < squares[row].length;
    }

    /**
     * Enumeración que representa las direcciones de movimiento
     */
    private enum MoveDirection {
        RIGHT, DOWN, LEFT, UP
    }
}
